OKUL KACISI 3D - tek dosya yapma (GitHub ile, telefondan)

1) github.com'da ucretsiz hesap ac, yeni bir depo (repository) olustur.
2) Bu zip'in icindekileri depoya yukle: main.cpp, zeltus klasoru, .github klasoru.
   (Tarayicida: Add file > Upload files. ".github" klasoru gizli olabilir; yuklenmezse
   Add file > Create new file ile ".github/workflows/windows.yml" adiyla olusturup icerigi yapistir.)
3) Depoda "Actions" sekmesi > "Windows exe" > "Run workflow".
4) 10-20 dk sonra bitince calismanin icindeki "OkulKacisi-exe" dosyasini indir. Tek dosya .exe, resim ve muzikler icinde.

Hata verirse Actions'taki kirmizi adima tikla, son satirlari bana gonder.

Bilgisayarda/Termux'ta kendin derlemek icin (gomulu):
  g++ -O2 -std=c++17 main.cpp -o okul -DGOMULU -DASSET_DIR='"zeltus"' $(pkg-config --cflags --libs sdl3 sdl3-image sdl3-mixer)
-DGOMULU yazmazsan oyun dosyalari eskisi gibi zeltus/Download klasorlerinden okur.

YAYINLAMADAN ONCE main.cpp icinde:
  HILE = false  (su an false)
  TEST_MOD = false  (su an true: karakterler kilitli kapinin otesinde baslar)
  girisMenu = true  (su an false: menu ve Rehber hic acilmaz!)
